[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/Z1npak42)

Important note：
⭐⭐⭐⭐⭐
My project was developed in Google Colaboratory, so I recommend that you use Google Colaboratory to reproduce my project. My project exported two formats from Google Colaboratory, namely .py and .ipynb. When reproducing the project, I recommend that you use .ipynb starting with backup to reproduce on Google Colaboratory.
The following are links to the duplicate codes, in order of visualization, analysis, preprocessing, and crawling.

https://colab.research.google.com/drive/1r8qgBispnRUtM_77neR8H9iN9rh0Bn1o?usp=sharing

https://colab.research.google.com/drive/1MzAsdyWv2FKP3zbwDFpLcVPV-WL36Bw0?usp=sharing

https://colab.research.google.com/drive/1emoiFvZnWVWjN3k5hDf8ZDKxAWZJuI00?usp=sharing

https://colab.research.google.com/drive/13o9xrjdLFA6CDYYI_tMNz7FDlnP-f4AC?usp=sharing

Here is a backup link for the entire project:
https://github.com/rayford295/Palestinian-Israeli-conflict

If you want to open it locally using VS Code, I beg you to modify the path of each file, because the file path is based on Google colab and is in the form of content/, and you need to modify it. And I'm not sure about your python version, there may be a version conflict. Therefore, I highly recommend you to use Google colab to reproduce.

⭐⭐⭐
project name: Analysis of the Palestinian-Israeli Conflict from Chinese and English Language Perspectives

research problem
What are the differences between Chinese and English media’s coverage of the Israeli-Palestinian conflict? Do two different languages have an impact on the same thing?

Project Description
This project analyzes and compares Chinese and English media reports on the Palestinian-Israeli conflict. The goal is to reveal reporting biases and differences in opinions under different language backgrounds using data analysis technology in Python.

Data collection and data sources
- Wikipedia Palestinian-Israeli Conflict (English and Chinese versions)
- Google News on Israeli-Palestinian conflict (English and Chinese versions)

Data collection methods
- Use the `yifan_scrape_wikipedia_page` function to scrape content about the Israeli-Palestinian conflict from Wikipedia.
- Use the `yifan_save_news_to_csv` function to scrape news reports about the conflict from the RSS feed of Google News.

Data preprocessing
Use Python for text processing, including cleaning, word segmentation and feature extraction. Process Chinese and English text and save the processed data as CSV files.

Analysis methods and visualization
1. Keyword and word frequency analysis
2. Time series analysis
3. Text similarity analysis
4. Sentiment Analysis
5. Topic modeling analysis
6. Language style analysis

Analyze results
- Chinese and English datasets show similarities in terms of keywords and word frequency.
- Time series analysis reveals temporal trends in news coverage.
- The similarity between Chinese and English texts is very high.
- Both Chinese and English texts tend to be neutral in sentiment analysis.
- Themes in Chinese and English are similar and reflect common global or cross-cultural concerns.
- The English text on Wikipedia is richer in language style than Chinese, while the language style in Google News Chinese is richer than English.

visual description
1. Bar chart: Displays the top 10 keywords and their frequencies in the Google News English data set.
2. Word cloud graph: Generate a word cloud based on the Wikipedia English China-Pakistan conflict data set.
3. Pie chart: Shows the frequency distribution of the top 5 keywords in the Wikipedia English Sino-Pakistani conflict data set.
4. Line chart: Shows the time trend of the number of articles published in the Google News Chinese and English data sets.
5. Heat map: shows the similarity scores between different texts.
6. Histograms and box plots: display the results of sentiment analysis.

future work directions
- Expand and diversify data sets.
- Perform deeper semantic analysis.
- Optimize and refine machine learning models.
